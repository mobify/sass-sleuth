#!/bin/bash
sudo patch -R /System/Library/Frameworks/WebKit.framework/Frameworks/WebCore.framework/Resources/inspector/inspector.js inspector.diff
