#!/bin/bash
sudo patch -b -z Main.js.orig /System/Library/PrivateFrameworks/WebInspector.framework/Versions/A/Resources/Main.js inspector.diff
